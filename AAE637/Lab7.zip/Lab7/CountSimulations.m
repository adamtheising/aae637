%% Compare poisson and normal distributions at different theta values
clear;
clc;

%% Theta = 1
n = -3:7;
theta = 1;
y = poisspdf(n,theta);
y2 = normpdf(n,theta,sqrt(theta));
plot(n,y,'o',n,y2,'x')
%%  Theta = 3
n = 0:10;
theta = 3;
y = poisspdf(n,theta);
y2 = normpdf(n,theta,sqrt(theta));
plot(n,y,'o',n,y2,'x')
%% Theta = 10
n = 0:20;
theta = 10;
y = poisspdf(n,theta);
y2 = normpdf(n,theta,sqrt(theta));
plot(n,y,'o',n,y2,'x')
%% Theta = 100
n = 0:200;
theta = 100;
y = poisspdf(n,theta);
y2 = normpdf(n,theta,sqrt(theta));
plot(n,y,'o',n,y2,'x')