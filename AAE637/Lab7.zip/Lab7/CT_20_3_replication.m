%%  Replication of Cameron and Trivedi (2005) - Chapter 20.3
%   Adam Theising - h/t to Drew Schreiber for some useful chunks of code

%% Preliminaries
delete('output.txt'); 
diary('output.txt'); 
diary on; % Start a diary of computations

clear;              %   Clear the memory;
clc;                %   Clear the command window;
clear global;       %   Clear global variables from memory;

global rhsvar critic_limit iter_limit numobs do_step func_name dh depend;

%%  Reading in and cleaning the data
[base_data,varnames,raw] = xlsread('newranddata');

var_need = {'mdvis','logc','idp','lpi','fmde','linc','lfam','xage','female',...
            'child','fchild','black','educdec','physlm','disea',...
            'hlthg','hlthf','hlthp'};

parnames = var_need(2:end);
parnames = ['constant' parnames]; % If we need a constant 

z = pull_data(varnames,var_need,base_data);
z(any(isnan(z),2),:) = []; % drop rows with Na

depend = z(:,1);
rhsvar = z(:,2:end);
rhsvar = [ones(length(depend),1) rhsvar]; % add constant column

[numobs,numc] = size(rhsvar);

%% Frequency table and histogram:
table20_3 = tabulate(depend);
hist20_3 = histogram(depend);

%% Declare and calculate the poisson MLE:
func_name = ('lf_poisson');

critic_limit = 1e-7;    % Critical limit. Terminal Condition.
iter_limit = 2500;      % Iteration limit for algorithm.
do_step = 1;            % Variable steplength if 1.
dh = 1e-7;              % For gradient. Perturbs function by 2*dh.

startvalue = inv(rhsvar'*rhsvar)*rhsvar'*log(depend+0.001);

[ml_parm,covb] = max_bhhh(startvalue,parnames);
unres_llf = sum(feval(func_name,ml_parm));

%% Predicted values
pred_poisson = exp(rhsvar*ml_parm); % Predicted expectation
prob_matrix = zeros(numobs,10); %(numobs,11) if we want to include >9

% First element: P[y=0] = f(y = 0| theta)
prob_matrix(:,1) = exp(-pred_poisson); 

% We will use Panjer recursion here
% P[y=k] = P[y=k-1]*theta/k for k>=1
for i = 2:10
   prob_matrix(:,i) = prob_matrix(:,i-1).*(pred_poisson/(i-1));
end

% All values > 9
%prob_matrix(:,11) = 1 - sum(prob_matrix, 2);

% Replication of Rows 1&2, Table 20.6 in Cameron and Trivedi
prob_frequency = [table20_3(1:10, 3)'; 100*mean(prob_matrix, 1)]

%% Measure of model fit (Greene 21.9.1)
lambdahat = exp(rhsvar * ml_parm);
num = sum(((depend - lambdahat)./(lambdahat.^(0.5))).^2);
den = sum(((depend - mean(depend))./(mean(depend).^(0.5))).^2);
R2_p = 1 - num/den;

%% Likelihood ratio test on gender:
%   Estimate a restricted version of the model:
rhsvar(:,9) =[];
rhsvar(:,10) = [];
parnames(:,9) = [];
parnames(:,10)  =[];
startvalue = inv(rhsvar'*rhsvar)*rhsvar'*log(depend+0.001);
[ml_rest,covb_rest] = max_bhhh(startvalue,parnames);
res_llf = sum(feval(func_name,ml_rest));

LR = 2*(unres_llf - res_llf);
crit_val = chi_bwg(0.05,2,LR);



