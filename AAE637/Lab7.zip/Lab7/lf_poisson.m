function  llf = lf_poisson(gamma)
    global rhsvar depend;
    llf = - exp(rhsvar*gamma) + depend.*(rhsvar*gamma) - log(factorial(depend));
    %llf = - exp(rhsvar*gamma) + depend.*(rhsvar*gamma) - gam_ln_bwg(depend + 1);
end

