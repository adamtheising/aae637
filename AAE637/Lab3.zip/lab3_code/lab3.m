clear;					    % command to clear memory 
clc;                        % command to clear the command window
[dat,txt,raw] = xlsread('invest.xlsx','Sheet1'); % import data  

%% Question 9.25(c)
% Estimate standard linear regression
y = dat(:,1);
x = dat(:,2:4);
coef_names = txt(:, 2:4);
[beta,se,~,~,covb] = basic_ols_proc(x,y,coef_names,1);

% Create restriction and find Wald stat
R_trans = [0, 0, 1, 0; 0, 0, 0, 1]; % This is R'
theta = R_trans*beta; % theta = RBeta - Beta0 (where Beta0 = [0,0])
inner = R_trans*covb*transpose(R_trans); % inner = R'*Var(beta)*R

Wald_stat1 = transpose(theta)*inv(inner)*theta

clear x coef_names beta se covb R_trans theta inner 

%% Question 9.25(d)
% Create new variables
Q2 = (dat(:,2)).^2;
C2 = (dat(:,3)).^2;
D2 = (dat(:,4)).^2;
QC = dat(:,2).*dat(:,3);
QD = dat(:,2).*dat(:,4);
CD = dat(:,3).*dat(:,4);

y = dat(:,1);
x = horzcat(dat(:,2:4),Q2,C2,D2,QC,QD,CD);
coef_names = horzcat(txt(:, 2:4),'Q2','C2','D2','QC','QD','CD');
[beta,se,~,~,covb] = basic_ols_proc(x,y,coef_names,1);

% Create restriction and find Wald stat
R_trans = [0, 0, 0, 0, 1, 1, 1, 1, 1, 1]; % This is R'
theta = R_trans*beta; % theta = RBeta - Beta0 (where Beta0 = [0,0])
inner = R_trans*covb*transpose(R_trans); % inner = R'*Var(beta)*R

Wald_stat2 = transpose(theta)*inv(inner)*theta

clear beta C2 CD coef_names covb D2 inner Q2 QC QD R_trans se theta x y

%% BASIC GRID SEARCH EXAMPLE
clear;
clc();
%% Construct a grid from 0 to 5 in both dimensions
m1 = 6; m2 = 6; % Number of points in each direction of grid.
G1 = linspace(0,5,m1);
G2 = linspace(0,5,m2);
grid = ones(m1,m2)*(-1e+10) % ILLUSTRATIVE: draw starting grid

%% Set initial values - don't set too large or you'll never leave.
x1_max = -1e+10; % Value of x1 that maxes function
x2_max = -1e+10; % Value of x2 that maxes function
f_max = -1e+10; % Value of function at its maximum

%% Loop through the grid filling in points
for i = 1:m1 % Loop through every x1 value in grid
    for j = 1:m2 % Loop through every x2 value in grid
        f = G1(i) - 0.2*G1(i)^2 + G2(j) - 0.3*G2(j)^2; % Function value at (i,j)
        grid(i,j) = f % ILLUSTRATIVE: Fill in the grid cell with function value
        if f > f_max; % Replace values below if condition is met.
            f_max = f;
            x1_max = G1(i);
            x2_max = G2(j);
        end
    end
end
fprintf('\nBasic grid search:\n')
fprintf('\nMax of%8.4f attained at x1 =%8.4f and x2 =%8.4f\n',f_max,x1_max,x2_max)
