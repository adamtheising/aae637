% This function performs the non-linear least squares estimators using
% Gauss-Newton algorithm and conducts the following joint test: 
%(1) All elasticities sum up to zero
%(2) The own-price elasticity of beer = the negative of the cross-price 
%    elasticity of beer with respect to the price of liquor 
%(3) The income elasticity is equal to one

function[betas_unres,covb_unres,betas_res,covb_res,sse_unres,sse_res,fstat] =  nls_beer_lab(b0,y,names)
% *** Define global variables and settings ***
    global critic_limit iter_limit z numobs do_step func_name minstep;
for i =1:2
    if i==2
        func_name=('beer_fun_res');
        b0 = vertcat(b0(1),b0(2));
        names    = {'beta_1','beta_beer'};
    end
    
    betas=b0;
    crit = 1;                   % Initialize critical % coef. change
    s=1;                        % Initialize step length
    iter = 1;                   % Initialize iteration count
    k = length(betas);          % Number of parameters
    diary on;                   % Turn on output to file
    disp('  ');

 % *** Start GN Method ***
    while (critic_limit < crit ) &&  (iter < iter_limit) % Begin loop
     z = Grad(betas,func_name,numobs);   % Compute numerical gradients
     u_lag = y - feval(func_name,betas); % Compute errors given previous betas                        
     sl=(z'*z)\(z'*u_lag);      % GN Step length (or sl=inv(z'*z)*z'*u)
     if do_step == 1                   % Use a variable step length
       s = 1;                          % Initialize base step length of 1
       ss1 = 1; ss2 = 2;               % Intialize SSE's under 2 step lengths
       while (ss1 < ss2) && (s >=minstep)   % Loop to determine step length
          u1 = y - feval(func_name,(betas + s*sl/2));%Error w/SL/2 & curr. betas
          u2 = y - feval(func_name,(betas + s*sl));  %Error w/SL & curr. betas
          ss1 = u1'*u1;                % SSE w/SL/2 & curr. betas
          ss2 = u2'*u2;                % SSE w/SL & curr. betas
          s = s/2;                     % Update SL for next pass
       end 
     end 
     b = betas + s*sl;                 % Update parameters from prevoius
     u = y - feval(func_name,b);       % Create errors given current betas
     sse = u'*u;                       % Calc. SSE's given current betas
     % *** Printing Intermediate Results ***
     diary on;                        % Turn on output to file
     fprintf('Iteration: %3.0f, SSE value: %8.4f, and Step length: %5.4f\r', ...
           iter, sse, s); % Print iteration number, current SSE, and step length
     fprintf('Paramaters:\r');        % Print current paramater estimate

     disp(b');                          % Print out all if less than 7
     iter = iter + 1;                      % Update for next iteration
     crit = max(abs((b - betas)./betas));  % Evaluate change in coeff. 
     betas = b;                            % Create lag betas
    end
    
% *** Check if SSE function is convex ***
    H = hessian_bwg('sse_lab', betas);
    pos_def = all(eig(H) > 0);       % check if eigenvalues are all > 0
    if pos_def == 1
        disp('*** SSE function is convex ***')
    else
        error('*** SSE function is NOT convex ***')
    end     
    disp(' ');
 
% *** Compute covariance matrix and print out Final Results ***
  sighat2 = sse/(numobs - k);    % Unbiased est of error variance
  covb = inv(z'*z).*sighat2;
  if i==1
  fprintf('Final Results from the Unrestricted Model:');
  else
  fprintf('Final Results from the Restricted Model:');
  end
  disp(' ');
  stbls=sqrt(diag(covb));        % Column vector of param. std. errors
  tvalue=b./stbls;               % Column vector of t-values
  df= numobs-1;                  % Degrees of freedom for t-value
  pvalue=2*(1-tcdf(abs(tvalue),df));  % Column vector of param p-values 
  results=horzcat(b,stbls,tvalue,pvalue); % Build results matrix
  table_bwg(names,results,1);
  fprintf('Number of observations: %10.0f\r', numobs);
  fprintf('Unbiased estimate of error variance:  %10.4f\r', sighat2);
  fprintf('Final SSE: %4.3f\r', sse);
  ybar = mean(y);
  sst = y'*y - numobs*(ybar^2);
  r2 = 1 - (sse/sst);
  fprintf('R-Squared: %4.3f\r', r2);
  disp('  ')

  disp('Variance-Covariance Matrix for Estimated Coeff.:')
  disp(covb);
  diary off;
  if i==1
      betas_unres = betas;
      covb_unres = covb;
      num_param_unres = k;
      sse_unres = sse;
  else
      betas_res = betas;
      covb_res = covb; 
      sse_res = sse;
  end
end
num_res = 3;
df1 = num_res;
df2 = numobs-num_param_unres;
fstat= ((sse_res-sse_unres)/df1)/(sse_unres/df2);
disp('Now conduct the joint hypothesis test:')
disp('(1) All elasticities sum up to one')
disp('(2) The own-price elasticity of beer = the negative of the cross-price elasticity of beer ')
disp('    with respect to the price of liquor')
disp('(3) The income elasticity is equal to one')
disp(' ')
fprintf('F-stat: %4.4f\r', fstat);
disp(' ')
crit_val = critical_value(4,2,0.05,df1,df2);
disp(' ')
  if abs(fstat)>crit_val
      disp('We reject the joint null hypothesis that (1), (2), and (3) are all true')
  else
      disp('We do not reject the joint null hypothesis (1), (2), and (3) are all true')
  end
  %**********************************************************/ 

end
                
