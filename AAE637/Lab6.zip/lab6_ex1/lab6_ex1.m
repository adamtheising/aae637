%% Linear
clear;					    % command to clear memory 
clc;                        % command to clear the command window
clear global;               % command to global variables
global numobs X y do_step critic_limit iter_limit dh func_name minstep

[data,txt,raw] = xlsread('beer_data'); % import data  
[numobs,~] = size(data);               % get the number of observations

% Create variables
q_beer = data(:,1);
p_beer = data(:,2);
p_liquor = data(:,3);
p_other = data(:,4);
income = data(:,5);

% Create RHS and LHS variables for regression
X = horzcat(log(p_beer),log(p_liquor),log(p_other),log(income));
y = log(q_beer);

% Generate a vector of variable names
varname = horzcat('intercept',txt(:,2:5));

% Run linear regression
[beta_linear,se,tvalue,pvalue,covb,fstat,r2,rbar2,sighat2] = basic_ols_proc(X,y,varname,1);

%% Nonlinear


X = horzcat(p_beer,p_liquor,p_other,income);
y = q_beer;

beta0 = beta_linear;       % starting parameter values
func_name = ('beer_fun');  % function used for estimation
parname    = {'beta_1','beta_beer','beta_liquor','beta_other','beta_income'};

critic_limit  = 1e-7;  % percentage change in parameters (stopping criterion)
iter_limit    = 250;   % maximum number of iterations
do_step       = 1;     % use variable step length
minstep       = 0;     % Minimum possible step length
dh            = 1e-7;  % distance for evaluating gradients

% Run nonlinear least-squares regression using GN algorithm
[beta_unres,cov_unres,beta_res,cov_res,sse_unres,sse_res,fstat] = nls_beer_lab(beta0, y, parname);

