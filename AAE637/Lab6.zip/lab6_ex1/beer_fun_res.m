function [output]=beer_fun_res(beta)
global X
p_beer = X(:,1);
p_liquor = X(:,2);
p_other = X(:,3);
income = X(:,4);
    output=beta(1).*p_beer.^beta(2).*p_liquor.^(-beta(2)) ...
        .*p_other.^(-1).*income.^1;
end