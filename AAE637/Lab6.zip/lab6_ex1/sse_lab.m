function ret=sse_lab(betas)
  global y func_name
  output=feval(func_name,betas) ;
  u= y - output;
  ret=u'*u;
end
