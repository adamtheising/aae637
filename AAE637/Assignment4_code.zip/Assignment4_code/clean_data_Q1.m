%% Question 1 - prepare variables
% TVCOLOR: Number of televisions used (0 - 15)
TVCOLOR = dat(:,strcmp('TVCOLOR',txt));

% F_S = STORIES if a house or NAPTFLRS if an apartment
%   NAPTFLRS: Number of floors in apartment (1 - 9)
%   STORIES: Number of stories in a single-family home
%   (10: One story, 20: Two stories, 31: Three stories)
%   (32: Four or more stories (Set to 4 for modeling purposes)
%   (40: Split-level (Set to 2 for modeling purposes)
%   (50: Other type (Set to 1 for modeling purposes)
STORIES = dat(:,strcmp('STORIES',txt));
    STORIES(STORIES == -2) = 0;
    STORIES(STORIES == 10) = 1;
    STORIES(STORIES == 20) = 2;
    STORIES(STORIES == 31) = 3;
    STORIES(STORIES == 32) = 4;
    STORIES(STORIES == 40) = 2;
    STORIES(STORIES == 50) = 1;
NAPTFLRS = dat(:,strcmp('NAPTFLRS',txt));
    NAPTFLRS(NAPTFLRS == -2) = 0;
F_S = STORIES + NAPTFLRS;
clear STORIES NAPTFLRS;

% N_Rooms = Total number of rooms excluding bathrooms (BEDROOMS + OTHROOMS)
%   BEDROOMS: Number of bedrooms (0 - 20)
%   OTHROOMS: Number of rooms other than bedroom(s) and bathroom(s) (1 - 20)
BEDROOMS = dat(:,strcmp('BEDROOMS',txt));
    BEDROOMS(BEDROOMS == -2) = 0;
OTHROOMS = dat(:,strcmp('OTHROOMS',txt));
    OTHROOMS(OTHROOMS == -2) = 0;
N_Rooms = BEDROOMS + OTHROOMS;
    N_Rooms(N_Rooms == 0) = 1;
clear BEDROOMS OTHROOMS;

% StudioD = Dummy variable if housing is a studio apartment
%   STUDIO: Studio apartment (0: No, 1: Yes, -2: Not Applicable)
StudioD = dat(:,strcmp('STUDIO',txt));
    StudioD(StudioD == -2) = 0;

% HHINC = Household gross income using the mid-points of the ranges.
%         For the last category assume a gross income of $200,000;
%   MONEYPY: 2009 gross household income
% 	1	Less than $2,500	==>	1250
% 	2	$2,500 to $4,999	==>	3750
% 	3	$5,000 to $7,499	==>	6250
% 	4	$7,500 to $9,999	==>	8750
% 	5	$10,000 to $14,999	==>	12500
% 	6	$15,000 to $19,999	==>	17500
% 	7	$20,000 to $24,999	==>	22500
% 	8	$25,000 to $29,999	==>	27500
% 	9	$30,000 to $34,999	==>	32500
% 	10	$35,000 to $39,999	==>	37500
% 	11	$40,000 to $44,999	==>	42500
% 	12	$45,000 to $49,999	==>	47500
% 	13	$50,000 to $54,999	==>	52500
% 	14	$55,000 to $59,999	==>	57500
% 	15	$60,000 to $64,999	==>	62500
% 	16	$65,000 to $69,999	==>	67500
% 	17	$70,000 to $74,999	==>	72500
% 	18	$75,000 to $79,999	==>	77500
% 	19	$80,000 to $84,999	==>	82500
% 	20	$85,000 to $89,999	==>	87500
% 	21	$90,000 to $94,999	==>	92500
% 	22	$95,000 to $99,999	==>	97500
% 	23	$100,000 to $119,999==>	110000
% 	24	$120,000 or More	==>	200000
HHINC = dat(:,strcmp('MONEYPY',txt));
    HHINC(HHINC == -2) = 0;
    HHINC(HHINC == 1) = 1250;
    HHINC(HHINC == 2) = 3750;
    HHINC(HHINC == 3) = 6250;
    HHINC(HHINC == 4) = 8750;
    HHINC(HHINC == 5) = 12500;
    HHINC(HHINC == 6) = 17500;
    HHINC(HHINC == 7) = 22500;
    HHINC(HHINC == 8) = 27500;
    HHINC(HHINC == 9) = 32500;
    HHINC(HHINC == 10) = 37500;
    HHINC(HHINC == 11) = 42500;
    HHINC(HHINC == 12) = 47500;
    HHINC(HHINC == 13) = 52500;
    HHINC(HHINC == 14) = 57500;
    HHINC(HHINC == 15) = 62500;
    HHINC(HHINC == 16) = 67500;
    HHINC(HHINC == 17) = 72500;
    HHINC(HHINC == 18) = 77500;
    HHINC(HHINC == 19) = 82500;
    HHINC(HHINC == 20) = 87500;
    HHINC(HHINC == 21) = 92500;
    HHINC(HHINC == 22) = 97500;
    HHINC(HHINC == 23) = 110000;
    HHINC(HHINC == 24) = 200000; 
    HHINC(HHINC == 24) = 200000; 

% %<5 = % of HH members< 5 years old
% %5_14 = % of HH members between 5 and 14 years of age
% %15_19 = % of HH members between 15 and 19 years of age
% SeniorD = 1 if all household members are more than 59 years of age
%   NHSLDMEM: Number of household members (0 - 15)
%   HHAGE: Age of householder (16 - 95)
%   AGEHHMEMCAT2 - AGEHHMEMCAT14: Age category of second-fourteenth HH member
% 	1	< 5 years old	==>	ageless05 = 1
% 	2	5-9 years old	==>	age05to14 = 1
% 	3	10-14 years old	==>	age05to14 = 1
% 	4	15-19 years old	==>	age15to19 = 1
% 	5	20-24 years old	==>	none
% 	6	25-29 years old	==>	none
% 	7	30-34 years old	==>	none
% 	8	35-39 years old	==>	none
% 	9	40-44 years old	==>	none
% 	10	45-49 years old	==>	none
% 	11	50-54 years old	==>	none
% 	12	55-59 years old	==>	none
% 	13	60-64 years old	==>	ageplus59 = 1
% 	14	65-69 years old	==>	ageplus59 = 1
% 	15	70-74 years old	==>	ageplus59 = 1
% 	16	75-79 years old	==>	ageplus59 = 1
% 	17	80-84 years old	==>	ageplus59 = 1
% 	18	85 + years old	==>	ageplus59 = 1
cat_HH_head = dat(:,strcmp('HHAGE',txt));
    cat_HH_head(cat_HH_head <= 19) = 4;
    cat_HH_head(cat_HH_head >= 60) = 13;
    cat_HH_head(cat_HH_head >19 & cat_HH_head < 60) = 0;
AGEHHMEMCAT2 = dat(:,strcmp('AGEHHMEMCAT2',txt));
AGEHHMEMCAT3 = dat(:,strcmp('AGEHHMEMCAT3',txt));
AGEHHMEMCAT4 = dat(:,strcmp('AGEHHMEMCAT4',txt));
AGEHHMEMCAT5 = dat(:,strcmp('AGEHHMEMCAT5',txt));
AGEHHMEMCAT6 = dat(:,strcmp('AGEHHMEMCAT6',txt));
AGEHHMEMCAT7 = dat(:,strcmp('AGEHHMEMCAT7',txt));
AGEHHMEMCAT8 = dat(:,strcmp('AGEHHMEMCAT8',txt));
AGEHHMEMCAT9 = dat(:,strcmp('AGEHHMEMCAT9',txt));
AGEHHMEMCAT10 = dat(:,strcmp('AGEHHMEMCAT10',txt));
AGEHHMEMCAT11 = dat(:,strcmp('AGEHHMEMCAT11',txt));
AGEHHMEMCAT12 = dat(:,strcmp('AGEHHMEMCAT12',txt));
AGEHHMEMCAT13 = dat(:,strcmp('AGEHHMEMCAT13',txt));
AGEHHMEMCAT14 = dat(:,strcmp('AGEHHMEMCAT14',txt));
ages = horzcat(cat_HH_head, AGEHHMEMCAT2, AGEHHMEMCAT3, AGEHHMEMCAT4,...
               AGEHHMEMCAT5, AGEHHMEMCAT6, AGEHHMEMCAT7, AGEHHMEMCAT8, ...
               AGEHHMEMCAT9, AGEHHMEMCAT10, AGEHHMEMCAT11, AGEHHMEMCAT12,...
               AGEHHMEMCAT13, AGEHHMEMCAT14);
HH_members = dat(:,strcmp('NHSLDMEM',txt));

% Create 0-4 age percentage
ageless05 = ages;   
    ageless05(ageless05 == 1) = 1;
    ageless05(ageless05 ~= 1) = 0;
    ageless05 = sum(ageless05,2);
    ageless05 = ageless05./HH_members;
   
% Create 5-14 age percentage
age05to14 = ages;   
    age05to14(age05to14 == 1) = 0;
    age05to14(age05to14 == 2) = 1;
    age05to14(age05to14 == 3) = 1;
    age05to14(age05to14 ~= 1) = 0;
    age05to14 = sum(age05to14,2);
    age05to14 = age05to14./HH_members;

% Create 15-19 age percentage
age15to19 = ages;   
    age15to19(age15to19 == 1) = 0;
    age15to19(age15to19 == 4) = 1;
    age15to19(age15to19 ~= 1) = 0;
    age15to19 = sum(age15to19,2);
    age15to19 = age15to19./HH_members;
    
% Create senior dummy
SeniorD = ages;   
    SeniorD(SeniorD == 1) = 0;
    SeniorD(SeniorD >= 13) = 1;
    SeniorD(SeniorD ~= 1) = 0;
    SeniorD = sum(SeniorD,2);
    SeniorD = SeniorD./HH_members;
    SeniorD(SeniorD < 1) = 0;
    
clear AGEHHMEMCAT2 AGEHHMEMCAT3 AGEHHMEMCAT4 AGEHHMEMCAT5 AGEHHMEMCAT6 ...
     AGEHHMEMCAT7 AGEHHMEMCAT8 AGEHHMEMCAT9 AGEHHMEMCAT10 AGEHHMEMCAT11 ...
     AGEHHMEMCAT12 AGEHHMEMCAT13 AGEHHMEMCAT14 cat_HH_head HH_members ages;

% ATHOME: Household member at home on typical week days (0: No, 1: Yes)
ATHOME = dat(:,strcmp('ATHOME',txt));

% TELLWORK: At least one member of HH telecommutes (0:No, 1:Yes)
TELLWORK = dat(:,strcmp('TELLWORK',txt));

% PerKWHPR = average price per KWH.
%   KWH: Total Site Electricity usage, in kilowatt-hours, 2009
%   DOLLAREL: Total Electricity cost, in whole dollars, 2009
KWH = dat(:,strcmp('KWH',txt));
DOLLAREL = dat(:,strcmp('DOLLAREL',txt));
PerKWHPR = DOLLAREL./KWH;
clear KWH DOLLAREL