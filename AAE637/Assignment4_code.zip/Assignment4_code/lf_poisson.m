function  llf = lf_poisson(gamma)
    global rhsvar depvar;
    llf = - exp(rhsvar*gamma) + depvar.*(rhsvar*gamma) - log(factorial(depvar));
    %llf = - exp(rhsvar*gamma) + depend.*(rhsvar*gamma) - gam_ln_bwg(depend + 1);
end

