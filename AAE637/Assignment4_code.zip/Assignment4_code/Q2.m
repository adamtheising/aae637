%% Question 2: Negative binomial
% Preliminaries
delete('output2.txt'); 
diary('output2.txt'); 
diary on; % Start a diary of computations

clear;              %   Clear the memory;
clc;                %   Clear the command window;
clear global;       %   Clear global variables from memory;

global rhsvar critic_limit iter_limit numobs do_step func_name dh depvar...
    stepmin;

%%  Reading in and cleaning the data
[base_data,varnames,raw] = xlsread('newranddata');

var_need = {'mdvis','logc','idp','lpi','fmde','linc','lfam','xage','female',...
            'child','fchild','black','educdec','physlm','disea',...
            'hlthg','hlthf','hlthp'};

parnames = var_need(2:end);
parnames = ['constant' parnames]; % If we need a constant 
parnames_pois = char(parnames);
z = pull_data(varnames,var_need,base_data);
z(any(isnan(z),2),:) = []; % drop rows with Na

depvar = z(:,1);
rhsvar = z(:,2:end);
rhsvar = [ones(length(depvar),1) rhsvar]; % add constant column

[numobs,numc] = size(rhsvar);

%% First: Declare and calculate the poisson MLE:
func_name = ('lf_poisson');

critic_limit = 1e-7;    % Critical limit. Terminal Condition.
iter_limit = 2500;      % Iteration limit for algorithm.
do_step = 1;            % Variable steplength if 1.
dh = 1e-7;              % For gradient. Perturbs function by 2*dh.
stepmin       = 1e-6;

startvalue = inv(rhsvar'*rhsvar)*rhsvar'*log(depvar+0.001);

[ml_parm,covb] = max_bhhh(startvalue,parnames_pois);
pois_llf = sum(feval(func_name,ml_parm));

%% Negative binomial count model (MLE)
func_name = ('lf_negbin2');

% Add the dispersion parameter theta
startvalue = vertcat(startvalue,1);
parnames = [parnames 'theta']; 
parnames_nb = char(parnames);

[nb_parm,nbcovb] = max_bhhh(startvalue,parnames_nb);

nb_llf = sum(feval(func_name,nb_parm));


%% Hypothesis testing:
% LR test: compare likelihood function values of Poisson and NB
l_ratio = 2*(nb_llf - pois_llf);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(0.05,1,l_ratio);
fprintf('\nThe distribution is not Poisson.\n')

% Wald-style test: 1/theta = 0 => theta <= some really big number
t_stat = (nb_parm(19)- 10000000000)/nbcovb(19,19)
fprintf('\nThe t-stat is %4.4f.\n', t_stat);
fprintf('\nReject H0: distribution is not Poisson.\n')

% LM test: use restricted model
rest_parm = vertcat(nb_parm(1:18),100000000000);
score = Grad(rest_parm,'lf_negbin2_lm',1);
LM = (-1)*score*(-inv(hessian_bwg('lf_negbin2_lm',rest_parm)))*score';
fprintf('\nThe score test value is: %4.4f\n', LM);
crit = chi_bwg(0.05,1,LM);


