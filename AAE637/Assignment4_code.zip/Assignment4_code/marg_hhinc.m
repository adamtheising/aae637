function [diff] = marg_hhinc(beta)
    global rhsvar;
    means = mean(rhsvar(:,[1:10 12]));
     
    athome  = beta(5) * exp(means*beta([1:10 12]) + beta(11));
    nothome = beta(5) * exp(means*beta([1:10 12])           );
    
    diff = athome - nothome;
end