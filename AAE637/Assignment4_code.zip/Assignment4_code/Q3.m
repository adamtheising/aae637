%%  Assignment 4: Question 3 -- Code sketches
%   by A.T. - h/t Cenci & Schreiber for some useful chunks of code

%% Preliminaries
delete('output3.txt'); 
diary('output3.txt'); 
diary on; % Start a diary of computations

clear;              %   Clear the memory;
clc;                %   Clear the command window;
clear global;       %   Clear global variables from memory;

global numobs do_step critic_limit iter_limit dh func_name depvar rhsvar ...
       parnames numc trunc stepmin;
   
%%  Reading in data
[dat,~,raw] = xlsread('recs_data_2009_elec_18','Data');
[~,txt,~] = xlsread('recs_data_2009_elec_18','Data', '1:1'); 

%% Clean data
clean_data_Q3
clear AC_x_CDD Air_Cond direct_vars Elec_Heat Heat_x_HDD ln_CDD65 ln_HDD65 nonzero

% No intercept with OLS procedure
parnames = {'ln_CDD65','ln_HDD65','House_age','Elec_Pr',...
    'Tot_SqFt_H/C','Elec_Stove','EnergyStar','Elec_Water','Air_Cond',...
    'Elec_Heat','AC_x_CDD','Heat_x_HDD'};
%%
% Scale variables: 
% if var is not a dummy or the intercept (mean > 1) rescale by 10
while mean(mean(rhsvar)>1)
	rhsvar(:,mean(rhsvar)>1) = rhsvar(:,mean(rhsvar)>1)/10;
end
%%
%%%%%%%%%%%%%%%%%%%%%
% CUT DATA DOWN TO COMPARABLE SUBSAMPLE
rhsvar = rhsvar(depvar < 10001,:);
depvar = depvar(depvar < 10001,:);

[numobs,numc] = size(rhsvar);
%% Question 3.a : basic OLS procedure
[beta,se,tval,pval,vcov_mat,fstat,r2,rbar2,sighat2] = basic_ols_proc(rhsvar,depvar,parnames,1);
coef_names = horzcat('Constant',parnames); % Include constant in table parnames
disp('  ');
fprintf('Nr. of observations used = %8.0f \n', numobs);
fprintf('F-statistic = %4.4f \n', fstat);
fprintf('R^2 =  %4.4f \n', r2);
fprintf('adjusted R^2 =  %4.4f \n', rbar2);
fprintf('Estimate of the error variance = %10.4f \n', sighat2');
coef_ests = horzcat(beta, se, tval, pval); % concat results of interest
table_bwg(coef_names, coef_ests, 1); % output using table_bwg.m

%% Question 3.b : elasticity

% Price elast = dQ/dP * (P_bar/ Q_bar)
price_bar = mean(rhsvar(:,4));
kwh_bar = mean(depvar);
elast = beta(5)*(price_bar/kwh_bar);
elast_se = sqrt(((price_bar/kwh_bar)^2)*vcov_mat(5,5));

ttest_0 = elast/elast_se;
ttest_neg1 = elast+1/elast_se;

%% Question 3.c : average marg impact of CDD w/ or w/o AC

% Marginal effect = dQ/dCDD = beta2/CDD_bar + AC*beta12/CDD_bar
CDD_bar = mean(dat(:,2));
marg_AC = beta(2)/CDD_bar + beta(12)/CDD_bar;
marg_noAC = beta(2)/CDD_bar;

% First term of marg_AC = marg_noAC: they drop out in t-test
diff_cdd = beta(12)/CDD_bar;
diff_cdd_se = sqrt(((1/CDD_bar)^2)*vcov_mat(12,12));
ttest_avgme = diff_cdd/diff_cdd_se;

%% Question 3.d : truncated maximum likelihood
% Start by truncating data -- pcKWH > 3000
trunc = 3000;
depvar_trun = depvar(depvar > trunc & depvar < 10001,:);
rhsvar_trun = rhsvar(depvar > trunc & depvar < 10001,:);
rhsvar_trun = [ones(length(depvar_trun),1) rhsvar_trun];
parnames_trun = char('constant', 'ln_CDD65','ln_HDD65','House_age','Elec_Pr',...
    'Tot_SqFt_H/C','Elec_Stove','EnergyStar','Elec_Water','Air_Cond',...
    'Elec_Heat','AC_x_CDD','Heat_x_HDD');

% settings for MLE:
rhsvar = rhsvar_trun;
depvar = depvar_trun;
clear depvar_trun rhsvar_trun
%%
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-6;
iter_limit    = 10000;   
do_step       = 1;
dh            = 1e-6;
stepmin        = 1e-6;

% use CRM to obtain inital values
b_ini = inv(rhsvar'*rhsvar)*rhsvar'*depvar;
df = numobs - numc;
ehatt = depvar - rhsvar*b_ini;
sset = ehatt'*ehatt;
sigsqhat  = sset/df;
%%
% add signma parameter
b_ini = vertcat(b_ini,sigsqhat);
parnames_trun = char('constant', 'ln_CDD65','ln_HDD65','House_age','Elec_Pr',...
    'Tot_SqFt_H/C','Elec_Stove','EnergyStar','Elec_Water','Air_Cond',...
    'Elec_Heat','AC_x_CDD','Heat_x_HDD','sigma2');

% declare funcional form for MLE
func_name = ('truncate_llf');

%%
% estimate MLE using BHHH
[b_mle,c_mle,llf] = max_bhhh(b_ini,parnames_trun);