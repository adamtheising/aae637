%%  Assignment 4: Question 1 -- Code sketches
%   by A.T. - h/t Cenci & Schreiber for some useful chunks of code

%% Preliminaries
delete('output1.txt'); 
diary('output1.txt'); 
diary on; % Start a diary of computations

clear;              %   Clear the memory;
clc;                %   Clear the command window;
clear global;       %   Clear global variables from memory;

global numobs do_step critic_limit iter_limit dh func_name depvar rhsvar ...
       parnames rhsres numc stepmin;
   
%%  Reading in data
[dat,~,raw] = xlsread('RECS_Data_assign_4');
% read var names using first column only
[~,txt,~] = xlsread('RECS_Data_assign_4', '1:1'); 

%% Clean data
clean_data_Q1 % Call .m cleaning file directly

depvar = TVCOLOR;
rhsvar = horzcat(F_S, N_Rooms, StudioD, HHINC, ageless05, age05to14, ...
                 age15to19, SeniorD, TELLWORK, ATHOME, PerKWHPR);
rhsvar = [ones(length(depvar),1) rhsvar];
parnames = char('constant', 'F_S', 'N_Rooms', 'StudioD', 'HHINC', ...
                'ageless05', 'age05to14', 'age15to19', 'SeniorD', ...
                'TELLWORK', 'ATHOME', 'PerKWHPR');
clear F_S N_Rooms StudioD HHINC ageless05 age05to14 age15to19 SeniorD ...
      ATHOME TELLWORK PerKWHPR DOLLAREL KWH TVCOLOR;
  
% Scale variables: 
% if var is not a dummy or the intercept (mean > 1) rescale by 10
while mean(mean(rhsvar)>1)
	rhsvar(:,mean(rhsvar)>1) = rhsvar(:,mean(rhsvar)>1)/10;
end

%% Q1.a: ML estimation - Poisson
% settings for MLE:
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-6;
iter_limit    = 1000;   
do_step       = 1;
dh            = 1e-6;
stepmin       = 1e-6;

% use CRM to obtain inital values
b_ini = inv(rhsvar'*rhsvar)*rhsvar'*depvar;

% declare funcional form for MLE
func_name = ('lf_poisson');

% estimate MLE using BHHH
[b_mle,c_mle,llf] = max_bhhh(b_ini,parnames);
llf_u = sum(llf);

%% Measures of explanatory power (Greene, p804-805)
l_hat = exp(rhsvar*b_mle);
y_bar = mean(depvar);

% measure 1: R^2 based on the standardized residuals
num1 = sum(((depvar - l_hat)./(l_hat.^(0.5))).^2);
den1 = sum(((depvar - y_bar)./(y_bar.^(0.5))).^2);
r_p = 1 - num1/den1;

% measure 2: fit measure based on the deviances (Cameron and Windmeijer, 1993)
num2 = depvar.*log(depvar./l_hat) - (depvar - l_hat);
den2 = depvar.*log(depvar./y_bar);
r_d = 1 - nansum(num2)/nansum(den2);

% measure 3: pseudo-R^2 or likelihood ratio index
llf_1 = sum(-exp(rhsvar*b_mle)+depvar.*(rhsvar*b_mle)-gammaln(depvar + 1));
llf_2 = sum(-y_bar            +depvar.*log(y_bar)    -gammaln(depvar + 1));
r_lri = 1- (llf_1/llf_2);

% printing results
disp(' ');
disp('Measures of explanatory power (Greene, p804-805)');
fprintf('\nThe R2_p is: %2.4f\r', r_p);
fprintf('\nThe R2_d is: %2.4f\r', r_d);
fprintf('\nThe R2_LRI is: %2.4f\r', r_lri);
disp(' ');

%% Question 1.b : LR test with age variabes
clear l_hat y_bar num1 den1 num2 den2 llf_1 llf_2 r_p r_d r_lri;

% estimate restricted model without variables for age
rhsres = rhsvar(:,[1:5 9:12]);
[~,nl] = size(parnames);
parnames_res = parnames([1:5 9:12], 1:nl);
func_name = ('lf_poisson_res');

b_ini_res = inv(rhsres'*rhsres)*rhsres'*depvar;

[b_res,cv_res,llf_res] = max_bhhh(b_ini_res,parnames_res);

% restricted LLF
llf_r = sum(feval(func_name,b_res));

% perform likelihood ratio test
l_ratio = 2*(llf_u - llf_r);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(0.05,4,l_ratio);

%% Question 1.c: marginal impacts for HOME vs. NOT.
clear rhsres nl parnames_res b_ini_res b_res c_res llf_r l_ratio;

% calculate difference of marginal effects
diff = marg_hhinc(b_mle);
% Delta Method to obtain variance of test statistic
diff_der = Grad(b_mle,'marg_hhinc',1);
diff_cov = diff_der * c_mle * diff_der';

% perform Wald test
wstat = (diff - 0)' * diff_cov^-1 * (diff - 0);
fprintf('\nThe difference of the marginals is: %8.4f\n', diff);
fprintf('\nThe W-stat for testing difference of marginals is %8.4f\n', wstat);
crit = chi_bwg(0.05,1,wstat);

%% Question 1.d: elasticities of HHINC vs. 1
m_hhinc = mean(rhsvar(:,5)); 
elast1 = b_mle(5)*m_hhinc; % elasticity at the mean
elast2 = mean(b_mle(5).*rhsvar(:,5)); % mean of elasticities
fprintf('\nThe elasticity of HHINC at the mean is: %8.4f', elast1);
fprintf('\nThe mean of HHINC elasticities is: %8.4f', elast2);
disp(' ');

% test unitary elasticities
tstat = (elast1 - 1)/sqrt(m_hhinc^2*c_mle(5,5));
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing elasticities = 1 is %8.4f (p-value = %5.4f)',...
        tstat, pvalue);
disp(' ');

%% Question 1.e: are elasticities from (d) different?
% calculate difference of elasticities
diff = elast_diff(b_mle);
fprintf('\nThe difference of the elasticities is: %8.4f\n', diff);

% Delta Method to obtain variance of test statistic
diff_der = Grad(b_mle,'elast_diff',1);
diff_cov = diff_der * c_mle * diff_der';

% perform Wald test
wstat = (diff - 0)' * diff_cov^-1 * (diff - 0);
fprintf('\nThe W-stat for testing difference of marginals is %8.4f\n', wstat);
crit = chi_bwg(0.05,1,wstat);

%% Question 1.f:
l_bar = lambda_bar(b_mle); % calculate mean values
y_bar = mean(depvar);

disp(' ');
fprintf('\nThe value of lambda at the mean is: %8.4f\n', l_bar);
fprintf('\nThe sample mean of y is: %8.4f\n', y_bar);

% Delta Method to obtain variance of test statistic
diff_der = Grad(b_mle,'lambda_bar',1);
diff_cov = diff_der * c_mle * diff_der';

% perform Wald test
wstat = (l_bar - y_bar)' * diff_cov^-1 * (l_bar - y_bar);
fprintf('\nThe W-stat for testing lambda_bar = y_bar is %8.4f\n', wstat);
crit = chi_bwg(0.05,1,wstat);

