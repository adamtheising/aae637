%% QUESTION 3 -- clean & prep variables
% First cuts:
dat(any(isnan(dat),2),:) = [] ; % First: drop rows with NaNs
nonzero = ~any(dat(:, [1 2])==0, 2); % rows with no 0 value in future log vars 
dat = dat(nonzero,:);  % delete rows with 0 in future log variables
%%
% ln(CDD65) & ln(HDD65)
ln_CDD65 = log(dat(:,strcmp('CDD65',txt)));
ln_HDD65 = log(dat(:,strcmp('HDD65',txt)));

% House_age, Elec_Pr, Tot_SqFt_H/C, Elec_Stove, EnergyStar, Elec_Water,
% Air_Cond, Elec_Heat
direct_vars = dat(:, [3 8 6 9 10 11]);
Air_Cond = dat(:,strcmp('Air_Cond',txt));
Elec_Heat = dat(:,strcmp('Elec_Heat',txt));

% Air_Cond x ln(CDD65) & Elec_Heat x ln(HDD65)
AC_x_CDD = Air_Cond .* ln_CDD65;
Heat_x_HDD = Elec_Heat .* ln_HDD65;

%% Get into global vars:
% RHS variables into matrix
rhsvar = horzcat(ln_CDD65, ln_HDD65, direct_vars, Air_Cond, Elec_Heat, ...
    AC_x_CDD, Heat_x_HDD);

% Dependent variable into vecotr
depvar = dat(:,strcmp('PercapKWH',txt));