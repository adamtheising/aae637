function l_bar = lambda_bar(beta)
    global rhsvar
    means = mean(rhsvar);
    l_bar = exp(means*beta);
end