function  llf = lf_negbin2(theta)
%% This is the "Negbin II" model.
% Conditional variance is mu(1+alpha*mu), where mu is cond. mean of data
% LLF derived from Greene 21.9.3 or Cameron Trivedi 20.4.1.
% NOTE: MAKE SURE TO ADD DISPERSION PARA TO END OF COEF VECTOR (theta)
    global rhsvar depvar;
    % USE ABS() FOR TEMP1 TO STOP FROM BOMBING OUT.
    temp1 = abs(theta(size(theta,1))); % This is the dispersion para: ALPHA
    temp2 = theta(1:(size(theta,1)-1),:); % All covariate parameters
    llf = gammaln(depvar + temp1) - gammaln(depvar + 1) - gammaln(temp1)...
        + temp1*log(temp1) - temp1.*log(temp1 + exp(rhsvar*temp2))...
        + depvar.*(rhsvar*temp2) - depvar.*log(temp1 + exp(rhsvar*temp2));
end