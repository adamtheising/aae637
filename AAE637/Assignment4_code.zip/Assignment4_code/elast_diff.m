function [diff] = elast_diff(beta)
    global rhsvar;
    m_hhinc = mean(rhsvar(:,5));

    elast1 = beta(5)*m_hhinc;
    elast2 = mean(beta(5).*rhsvar(:,5));

    diff = elast1 - elast2;
end