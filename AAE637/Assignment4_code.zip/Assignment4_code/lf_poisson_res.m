function llf = lf_poisson_res(gamma)
   global rhsres depvar;
   llf = -exp(rhsres*gamma)+depvar.*(rhsres*gamma)-gammaln(depvar + 1);
end
