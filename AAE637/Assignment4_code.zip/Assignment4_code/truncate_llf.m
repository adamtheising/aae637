function [llf_vec] = truncate_llf(b0)
   global rhsvar depvar trunc ;
   k=length(b0);
   betas=b0(1:(k-1));                   %*** Pull Out Betas ***
   sigmasq=b0(k)  ;                     %*** Error Variance ***
   sigma=sqrt(sigmasq);                 %*** Error Std. Dev ***
   error=depvar-rhsvar*betas;           %*** Error Term ***
   const = -(log(2*pi) +log(sigmasq))/2; %*** LLF Constant term ***
   joint_density=const - (error.^2)./(2.*sigmasq); %*** Joint Density *** 
   prob_pos=log(1-normcdf((trunc-rhsvar*betas)./sigma)) ;
                                  %*** Prob of being above lowerlimit ***
   llf_vec=joint_density - prob_pos ;  %*** This is Trunc. LLF (T x 1) ***  
end