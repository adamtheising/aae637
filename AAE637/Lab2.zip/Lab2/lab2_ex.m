%*** AAE 637 Lab 2 Example

%% Set up

clear;         % clean workspace
clc;           % clean command window 
clear global;  % clean global variables
global numrow  % define global variables 

%% Perform column sum

x = ones(20,5);  % input matrix
y = 5;           % input index (summation starts at y-th row)

colsum_x = ex_colsum_fun(x,y);   % column sum

