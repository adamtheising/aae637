%*** This function retuns the column sum starting at the specified row  

function [sum] = ex_colsum_fun(matrix,index)
global numrow   % define global variable
[numrow,numcol] = size(matrix);  % return the number of columns and rows

sum = zeros(1,numcol);   % generate initial zero vector

% for each iteration, add the values of i-th row to the cumulative-sum 
% vector in the previous iteration 
for i=index:numrow
    sum = sum + matrix(i,:);  
end

end

