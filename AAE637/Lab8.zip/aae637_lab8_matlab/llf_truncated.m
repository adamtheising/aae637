function llf = llf_truncated(beta)
   global rhsvar depvar numobs sigma a;
   sigma = 1;
   llf = -(numobs/2)*(log(2*pi)+log(sigma^2)) ...
         -(1/(2*sigma^2)).*(depvar-rhsvar*beta).^2 ...
         -log(1-normcdf((a-rhsvar*beta)/sigma));
end
