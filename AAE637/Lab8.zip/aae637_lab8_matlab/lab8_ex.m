%% Setup
clear;
clc;
clear global;

global critic_limit iter_limit do_step numobs a depvar rhsvar func_name dh

rng(1565773551)  % Seed for data generation. Control this to get the same draws  
                 % from distributions every time. To control the seed, use 
                 % rng('shuffle') to get random seed then identify its number 
                 % by rng(). Then you can control your random draws by
                 % rng(your number)
                 
%% Compare the pdf of full and truncated data
EDUC = nbinrnd(3,0.5,10000,1); % Year of education after conpulsory schooling
IQ = nbinrnd(100,0.5,10000,1); % IQ
PS = normrnd(0,1,10000,1); % People skills

% The true data generation process (How wage is really determined)
alpha = 65;       
beta_EDUC = 1;
beta_IQ = 0.05;
beta_PS = 1;

wage = alpha+beta_EDUC*EDUC+beta_IQ*IQ+beta_PS*PS;   % Full wage data

% Graphs
histogram(wage,'Normalization','pdf')

hold on

a = 72; % cutoff
WAGE_trun = wage(wage(:,1)>a,:);   % Truncated wage data (from below)

histogram(WAGE_trun,'Normalization','pdf')

%% Linear regression using full data

[numobs,~] = size(wage);

intercept = ones(numobs,1);
depvar = wage;
rhsvar = horzcat(intercept,EDUC,IQ);
parname    = char('intercept','beta_educ','beta_IQ');

[beta_full,~,~,~,~] = basic_ols_proc(rhsvar,depvar,parname,0);

%% Linear regression using truncated data

EDUC_trun = EDUC(wage(:,1)>a,:);
IQ_trun = IQ(wage(:,1)>a,:);

[numobs,~] = size(WAGE_trun);

intercept = ones(numobs,1);
depvar = WAGE_trun;
rhsvar = horzcat(intercept,EDUC_trun,IQ_trun);

[beta_sub,~,~,~,~] = basic_ols_proc(rhsvar,depvar,parname,0);

%% Truncated regression

% Setup for non-linear estimation
critic_limit  = 1e-7;  % percentage change in parameters (stopping criterion)
iter_limit    = 250;   % maximum number of iterations
do_step       = 1;     % use variable step length
dh            = 1e-7;  % distance for evaluating gradients

func_name = 'llf_truncated';

rhsvar = horzcat(intercept,EDUC_trun,IQ_trun);

[beta_trun,cov_trun,llf_trun] = max_bhhh(beta_sub,parname);
