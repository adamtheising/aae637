%%  Replication of Greene (5th Ed.): Example 21.4 
%   Adam Theising 

%% Preliminaries
delete('output.txt'); 
diary('output.txt'); 
diary on; % Start a diary of computations

clear;              %   Clear the memory;
clc;                %   Clear the command window;
clear global;       %   Clear global variables from memory;

global numobs do_step critic_limit iter_limit dh func_name depvar rhsvar ...
       numc parnames hetvar hetnames
%%  Reading in and cleaning the data
[base_data,varnames,raw] = xlsread('mroz_greene');

var_need = {'LFP','W_AGE','W_AGESQ','W_EDU','FAMINC','KIDS'};
parnames = var_need(2:end);
parnames = ['constant' parnames]; % If we need a constant 
parnames = char(parnames);

z = pull_data(varnames,var_need,base_data);
z(any(isnan(z),2),:) = []; % drop rows with Na

depvar = z(:,1);
rhsvar = z(:,2:end);
rhsvar = [ones(length(depvar),1) rhsvar]; % add constant column

% declare funcional form for MLE
func_name = ('probit_llf');

% settings for MLE:
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-7;
iter_limit    = 500;   
do_step       = 1;
dh            = 1e-7;

% initial values:
b_ini = (rhsvar'*rhsvar)\(rhsvar'*depvar); 

%% Homoskedastic estimation
% run probit MLE using Brian's function
[b_prob,c_prob,llf] = probit_bwg(b_ini);

% Marginal effect of age (take into account quadratic term)
age_marg=marg_age(b_prob);
grad_marg_age=Grad(b_prob,'marg_age',1);
se_age_marg=sqrt(grad_marg_age*c_prob*grad_marg_age');

% Marginal effect of education 
edu_marg=marg_edu(b_prob);
grad_marg_edu=Grad(b_prob,'marg_edu',1);
se_edu_marg=sqrt(grad_marg_edu*c_prob*grad_marg_edu');

% Marginal effect of income 
inc_marg=marg_inc(b_prob);
grad_marg_inc=Grad(b_prob,'marg_inc',1);
se_inc_marg=sqrt(grad_marg_inc*c_prob*grad_marg_inc');

% Discrete effect of having kids (NOT continuous)
kids_disc = disc_kids(b_prob);
grad_disc_kids = Grad(b_prob,'disc_kids',1);
se_kids_disc = sqrt(grad_disc_kids * c_prob * grad_disc_kids');

% Marginal effects table:
disp('********* MARGINAL EFFECTS *********');
fprintf('Age:       %8.8f (%8.7f)\n', age_marg, se_age_marg);
fprintf('Education: %8.8f (%8.7f)\n', edu_marg, se_edu_marg);
fprintf('Income:    %8.8f (%8.7f)\n', inc_marg, se_inc_marg);
fprintf('Kids*:     %8.8f (%8.7f)\n', kids_disc, se_kids_disc);
fprintf('\n*Note: Kids is a discrete effect.')

clear age_marg edu_marg grad_disc_kids grad_marg_age grad_marg_edu...
    grad_marg_inc inc_marg kids_disc se_age_marg se_edu_marg se_inc_marg...
    se_kids_disc z

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Alternative estimation methods using MATLAB optimizers...
% Since these fncts are MINIMIZERS - adapt the LLF as below!!!
% Built in "unconstrained" optimizer... NOTE: this gets stuck @ local max
[x, fval] = fminunc(@probit_llf_fmin, b_ini)
%%
% Built in "search" optimizer... DINGDING!: converges to global opt.
% options = optimset('PlotFcns',@optimplotfval); %turn on for iteration graph
[x, fval] = fminsearch(@probit_llf_fmin,b_ini)
%%
% MATLAB's built in generalized linear model function(s)
[b,dev,stats] = glmfit(rhsvar,depvar,'binomial','link','probit','constant','off');
stats.beta % Call estimated parameters out.
%clear x fval b dev stats

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Heteroskedastic case
%************* Change RHS Var Units *****************
rhsvar(:,2)=rhsvar(:,2)/100;
rhsvar(:,3)=rhsvar(:,3)/10000; %Note that this must be 100^2 for consistency
rhsvar(:,4)=rhsvar(:,4)/10;
rhsvar(:,5)=rhsvar(:,5)/10000;

% Bring in covariates for heteroskedastic correction
hetvar = rhsvar(:,5:6);
hetnames = parnames(5:6,:);
names = char(parnames,hetnames);

% Starting values for heteroskedastic model
b_ini = b_prob; % start with homosk ests
g_ini = [0.01, 0.01]'; % start with small values
p_ini = vertcat(b_ini, g_ini);

% declare funcional form for MLE
func_name = ('probit_hetero_llf');

% setttings for MLE:
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-7;
iter_limit    = 500;   
do_step       = 1;
dh            = 1e-7;

%% Hetero estimation and marginal effects
[b_phet,c_phet,llf_het] = max_bhhh(p_ini,names); 

% Education marginal effect
hmarg_edu = het_marg_edu(b_phet);
grad_hmarg_edu=Grad(b_phet,'het_marg_edu',1);
se_edu_marg= sqrt(grad_hmarg_edu*c_phet*grad_hmarg_edu');

% Age marginal effect
hmarg_age = het_marg_age(b_phet);
grad_hmarg_age=Grad(b_phet,'het_marg_age',1);
se_age_marg= sqrt(grad_hmarg_age*c_phet*grad_hmarg_age');

% Income marginal effect
hmarg_inc = het_marg_inc(b_phet);
grad_hmarg_inc=Grad(b_phet,'het_marg_inc',1);
se_inc_marg = sqrt(grad_hmarg_inc*c_phet*grad_hmarg_inc');

% Kids discrete* effect
%*Note: Greene (mistakenly?) takes the marginal effect in his table...
hdisc_kids = het_disc_kids(b_phet);
grad_hdisc_kids=Grad(b_phet,'het_disc_kids',1);
se_kids_disc = sqrt(grad_hdisc_kids*c_phet*grad_hdisc_kids');

% Marginal effects table:
disp('********* MARGINAL EFFECTS *********');
fprintf('Age:       %8.4f (%8.4f)\n', hmarg_age, se_age_marg);
fprintf('Education: %8.4f (%8.4f)\n', hmarg_edu, se_edu_marg);
fprintf('Income:    %8.4f (%8.4f)\n', hmarg_inc, se_inc_marg);
fprintf('Kids*:     %8.4f (%8.4f)\n', hdisc_kids, se_kids_disc);
fprintf('\n*Note: Kids is a discrete effect.')
