function [change]= het_disc_kids(param)
    global rhsvar numc hetvar
    % Prelims
    nonkid = [1:5];
    betas  = param(nonkid); % All except 
    gammas = param(numc+1:end);
    x_bar = mean(rhsvar(:,nonkid));
    het_bar = mean(hetvar);
    
    z_kids = (x_bar*betas + param(6))/(exp(gammas(1)*het_bar(1) + gammas(2)));
    z_nokids = (x_bar*betas)/(exp(gammas(1)*het_bar(1)));
    
    change = normcdf(z_kids) - normcdf(z_nokids);
end