function [marg]= marg_age(param)
   global rhsvar;
   xbar = mean(rhsvar);		%*** Mean Vector of RHS Variables ***
   xbar(:,3)= xbar(:,2).^2;
   z = (xbar*param);
   marg=normpdf(z).*(param(2,:)+2*param(3,:).*xbar(:,2));
end