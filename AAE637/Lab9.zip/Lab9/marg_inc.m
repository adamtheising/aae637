function [marg]= marg_inc(param)
   global rhsvar;
   xbar = mean(rhsvar);		%*** Mean Vector of RHS Variables ***
   z = (xbar*param);
   marg = normpdf(z).*param(5);
end