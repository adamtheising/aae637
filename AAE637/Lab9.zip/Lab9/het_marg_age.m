function [marg]= het_marg_age(param)
    global rhsvar numc hetvar
    % Prelims
    betas  = param(1:numc);
    gammas = param(numc+1:end);
    x_bar = mean(rhsvar);
    x_bar(:,3)= x_bar(:,2).^2;
    het_bar = mean(hetvar);

    % Create pdf var
    zrhs = x_bar*betas;
    zhet = exp(het_bar*gammas);
    zpdf = normpdf(zrhs./zhet);

    marg = zpdf*((param(2) + 2*param(3)*x_bar(:,2))/zhet);
end