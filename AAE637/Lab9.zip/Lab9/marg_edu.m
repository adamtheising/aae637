function [marg]= marg_edu(param)
   global rhsvar;
   xbar = mean(rhsvar);		%*** Mean Vector of RHS Variables ***
   z = (xbar*param);
   marg = normpdf(z).*param(4);
end