function [marg]= het_marg_edu(param)
    global rhsvar numc hetvar
    % Prelims
    betas  = param(1:numc);
    gammas = param(numc+1:end);
    x_bar = mean(rhsvar);
    het_bar = mean(hetvar);

    % Create pdf var
    zrhs = x_bar*betas;
    zhet = exp(het_bar*gammas);
    zpdf = normpdf(zrhs./zhet);

    marg = zpdf*(param(4)/zhet);
end