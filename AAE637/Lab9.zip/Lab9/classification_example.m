%% An classification application of maximum likelihood estimation
% Adam Theising
% H/t: adaptation of some notes by the UM-TC neuroscientist Kendrick Kay 

%% Preliminaries
delete('output.txt'); 
diary('output.txt'); 
diary on; % Start a diary of computations
clear;              %   Clear the memory;
clc;                %   Clear the command window;
global rhs lhs

%% Training data generation :
% Imagine we have information on 11000 water source's pH level and TSS count.
% Suppose this data is normalized (demeaned) across samples.
% Both characteristics are roughly normally distributed
rng(23571113)

% All 11000 water source
x_ph = randn(11000,1); 
x_tss = randn(11000,1); 

% This is our training set (we have the true y value)
x1 = x_ph(1:1000,:); % Normalized pH
x2 = x_tss(1:1000,:); % Normalized TSS count

% Suppose the gov't made a clean/not-clean determination for 1000 sources
lhs = (2*x1 + x2 + randn(size(x1))) > 1; % Clean water (yes = 1 / no = 0)

% Let's visualize our data in the 2D characteristic space
figure; hold on;
h1 = scatter(x1(lhs==0),x2(lhs==0),50,'k','filled'); % black dots for 0
h2 = scatter(x1(lhs==1),x2(lhs==1),50,'w','filled'); % white dots for 1
set([h1 h2],'MarkerEdgeColor',[.5 .5 .5]); % outline dots in gray
legend([h1 h2],{'y==0' 'y==1'},'Location','NorthEastOutside');
xlabel('pH');
ylabel('TSS');

%% Logistic regression setup and estimation :
% Construct RHS vars vector:
rhs = [x1 x2];
rhs(:,end+1) = 1; % Add a constant 

% Set initial paramater values
params0 = (ones(1,size(rhs,2)))'; % Set init params to 1.

% Run LLF minimization algorithm (note that we multiplied LLF by -1)
[params, fval] = fminsearch(@logistic_llf,params0);

% Compute the model's output for each data point
modelfit = 1./(1+exp(-rhs*params)) >= 0.5; % Set to clean = 1 if fit>=0.5

% Calculate % of data pts correctly classified
pctcorrect = sum(modelfit==lhs) / length(lhs) * 100;

%% Visualize the modeled results in 2D :
% Prepare a grid of points to evaluate the model at
ax = axis;
xvals = linspace(ax(1),ax(2),100);
yvals = linspace(ax(3),ax(4),100);
[xx,yy] = meshgrid(xvals,yvals);
% construct regressor matrix
X = [xx(:) yy(:)];
X(:,end+1) = 1;
% evaluate model at the points (but don't perform the final thresholding)
outputimage = reshape(1./(1+exp(-X*params)),[length(yvals) length(xvals)]);
% visualize the image (the default coordinate system for images
% is 1:N where N is the number of pixels along each dimension.
% we have to move the image to the proper position; we
% accomplish this by setting XData and YData.)
h3 = imagesc(outputimage,[0 1]); % the range of the logistic function is 0 to 1
set(h3,'XData',xvals,'YData',yvals);
colormap(hot);
colorbar;
% visualize the decision boundary associated with the model
% by computing the 0.5-contour of the image
[c4,h4] = contour(xvals,yvals,outputimage,[.5 .5]);
set(h4,'LineWidth',3,'LineColor',[0 0 1]); % make the line thick and blue
% send the image to the bottom so that we can see the data points
uistack(h3,'bottom');
% send the contour to the top
uistack(h4,'top');
% restore the original axis range
axis(ax);
% report the accuracy of the model in the title
title(sprintf('Classification accuracy is %.1f%%',pctcorrect));

%% Visualize the modeled results in 3D :
figure; hold on;
h1 = surf(xvals,yvals,outputimage);
set(h1,'EdgeAlpha',0); % don't show the edges of the surface
colormap(hot);
xlabel('pH');
ylabel('TSS');
zlabel('y');
view(-11,42); % set the viewing angle
% show some grid lines for reference
set(gca,'XGrid','on','XMinorGrid','on', ...
'YGrid','on','YMinorGrid','on', ...
'ZGrid','on','ZMinorGrid','on');

%% Now let's take the model to "testing" data :
% 1000 other points where we "only have" the pH and TSS values.
% We want to predit the water cleanliness
x3 = x_ph(1001:11000,:); % Normalized pH
x4 = x_tss(1001:11000,:); % Normalized TSS (total suspended particulates) count
lhs = (2*x3 + x4 + randn(size(x3))) > 1; % Clean water (yes = 1 / no = 0)

% Testing data construction
rhs = [x3 x4];
rhs(:,end+1) = 1; % Add a constant 

% Use params from "training" data for model fit to "testing" data
modelfit2 = 1./(1+exp(-rhs*params)) >= 0.5; % Set to clean = 1 if fit>=0.5
pctcorrect2 = sum(modelfit2==lhs) / length(lhs) * 100;

%% Contingency table
conting = zeros(size(lhs));
conting(lhs==0 & modelfit2==0) = 4; % Correct negative
conting(lhs==0 & modelfit2==1) = 3; % False positive
conting(lhs==1 & modelfit2==0) = 2; % False negative
conting(lhs==1 & modelfit2==1) = 1; % Correct positive

% Precision: when predicted clean, how often truly clean?
% Recall: when truly clean, how often predicted clean?
fprintf('-------------------------(PREDICTED VALS)---------- \n');
fprintf('---------------------- CLEAN ------ NOT CLEAN ----- \n');
fprintf('---- CLEAN ----      %8.1f        %8.1f   \n', sum(conting==1), sum(conting==2));
fprintf('-- NOT CLEAN --      %8.1f        %8.1f   \n', sum(conting==3), sum(conting==4));
fprintf('--------------------------------------------------- \n')
fprintf(' Precision: %8.2f \n', (sum(conting==1)/sum(conting==1 | conting == 3))*100)
fprintf(' Recall:    %8.2f \n', (sum(conting==1)/sum(conting==1 | conting == 2))*100)