function [llf] = probit_hetero_llf(b0)
   global rhsvar hetvar depvar ;
   [~,numbetas]=size(rhsvar);
   alp=b0(numbetas+1:end);  %*** Alpha Coefficients ***    
   betas=b0(1:numbetas);       %*** Beta Coefficients ***
%  sigmasq=(exp(hetvar*alp)).^2;
   sigma=exp(hetvar*alp);     %*** Std. Error of Error term ***
   z = (rhsvar*betas)./sigma;   %*** Standardized Value ***
   cdf_prob = normcdf(z);
   llf = depvar.*log(cdf_prob) + (1-depvar).*log(1-cdf_prob);    
end
