 function [tot_llf] = logistic_llf(b0)
    global rhs lhs
    lamb = exp(-rhs*b0);
    llf = lhs.*log(1./(1+lamb)) + (1-lhs).*log(1 - (1./(1+lamb)));
    tot_llf = -(sum(llf));    
 end