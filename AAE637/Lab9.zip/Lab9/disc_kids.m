function change = disc_kids(b0)
    global rhsvar;
    nonkid = [1:5]; % Kids is the 6th variables
    z_kids = mean(rhsvar(:,nonkid))*b0(nonkid) + b0(6); %b0(6) turned on
    z_nokids = mean(rhsvar(:,nonkid))*b0(nonkid) + 0; %bo(6) turned off
    change = normcdf(z_kids) - normcdf(z_nokids);
end
